package com.yusuf.travel;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelersBlogV21ApplicationTests {

	void contextLoads() {
	}

}
