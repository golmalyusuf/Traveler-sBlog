delete from  privacy;
delete from  locations;

INSERT INTO privacy (id, privacy_type) VALUES 
(1, 'Private'),
(2, 'Public');


INSERT INTO locations (id, location_name) VALUES 
(1, 'Sylhet'),
(2, 'Bandarban'),
(3, 'Khulna');
