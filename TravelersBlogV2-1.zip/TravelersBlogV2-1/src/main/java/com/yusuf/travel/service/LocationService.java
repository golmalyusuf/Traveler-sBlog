package com.yusuf.travel.service;

import java.util.ArrayList;
import java.util.List;

import com.yusuf.travel.model.Locations;

public interface LocationService { 
	 List<String> getAllLocations();
}
