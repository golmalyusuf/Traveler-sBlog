package com.yusuf.travel.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Controller
public class ViewPublicStatusController {

}
